package com.meet.paperface.model;

public class Task_Class {

    private String key;

    public Task_Class(){


    }

    public Task_Class(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
